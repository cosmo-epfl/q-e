#!/bin/bash

ln -s $plumedir/common_files/*.c .
ln -s $plumedir/common_files/*.h .
